﻿namespace Lightless.Animation
{
    public class TransactionDelta
    {
        public double R;
        public double G;
        public double B;
    }
}