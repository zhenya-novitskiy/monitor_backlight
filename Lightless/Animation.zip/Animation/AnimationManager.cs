﻿using System.Collections.Generic;
using System.Linq;
using System.Timers;
using Lightless.Animation;
using Lightless.Infrastructure;

namespace Lightless.Components
{
    public class AnimationManager
    {
        private Timer _timer;

        readonly LedCollection<PixelModel> _pixelModelCollection;

        private IAnimation _currentAnimation;
        public AnimationManager(LedCollection<PixelModel> pixelModel)
        {
            _pixelModelCollection = pixelModel;
            _timer = new Timer { Interval = 20, AutoReset = true };
            _timer.Elapsed += _timer_Elapsed;
            _timer.Start();
        }

        int i = 1;
        private void _timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            var resultCollection = _currentAnimation?.GetNextStep();
            if (resultCollection != null)
            {
                
                _pixelModelCollection.Update(() =>
                {
                    foreach (var pixelModel in _pixelModelCollection)
                    {
                        var updatedPixel = resultCollection.FirstOrDefault(x => x.Position == pixelModel.Index);
                        pixelModel.PixelData.R = updatedPixel.R;
                        pixelModel.PixelData.G = updatedPixel.G;
                        pixelModel.PixelData.B = updatedPixel.B;
                        pixelModel.PixelDataChanged();
                    }
                });
                i++;
            }
            else
            {
                _currentAnimation = null;
            }
        }

        public void TranslateToColor(List<Pixel> translateToColors)
        {
            _currentAnimation = new TranslateColorAnimation(_pixelModelCollection.Select(x => x.PixelData).ToList(), translateToColors);
        }
    }
}
